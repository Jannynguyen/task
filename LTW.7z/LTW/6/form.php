<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký Nhận Bản Tin</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
<h1>Đăng Ký Nhận Bản Tin</h1>
    <form name="regForm" onsubmit="return validateForm()">
        <div class="input-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Nhập email của bạn" required>

            <label for="fullname">Họ Tên:</label>
            <input type="text" id="fullname" name="fullname" placeholder="Nhập họ và tên" required>

            <input type="submit" value="Đăng ký">
        </div>
    </form>

    <footer>
        &copy; 2025 HỌC VIỆN CÔNG NGHỆ BƯU CHÍNH VIỄN THÔNG. All rights reserved.
    </footer>

    <script>
        function validateForm() {
            var email = document.getElementById("email").value;
            var fullname = document.getElementById("fullname").value;

            if (email.trim() == "" || fullname.trim() == "") {
                alert("Vui lòng nhập đủ email và họ tên.");
                return false;
            }

            alert("Đăng ký thành công!");
            return true;
        }
    </script>
</body>
</html>
