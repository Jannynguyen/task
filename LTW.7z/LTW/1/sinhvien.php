<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách sinh viên</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
    <h2>DANH SACH SINH VIEN</h2>

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã SV</th>
                <th>Họ và Tên</th>
                <th>Ngày sinh</th>
                <th>Giới </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>SV001</td>
                <td>Nguyễn Văn A</td>
                <td>1/1/2001</td>
                <td>Nam</td>
            </tr>
            <tr>
                <td>2</td>
                <td>SV002</td>
                <td>Trần Thị B</td>
                <td>20/2/2003</td>
                <td>Nữ</td>
            </tr>
            <tr>
                <td>3</td>
                <td>SV003</td>
                <td>Lê Văn C</td>
                <td>3/12/2007</td>
                <td>Nam</td>
            </tr>
            <tr>
                <td>4</td>
                <td>SV004</td>
                <td>Phạm Thị D</td>
                <td>2030</td>
                <td>8.Nữ</td>
            </tr>
            <tr>
                <td>5</td>
                <td>SV005</td>
                <td>Hoàng Văn E</td>
                <td>2006</td>
                <td>Nam.5</td>
            </tr>
        </tbody>
    </table>

</body>
</html>
