<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ĐĂNG KÝ NGÀNH HỌC</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
<h1>ĐĂNG KÝ NGÀNH HỌC</h1>
    <form id="registrationForm" onsubmit="return handleRegistration()">
        <label for="username">Tên đăng nhập (*):</label>
        <input type="text" id="username" name="username" value="SV001" required><br><br>

        <label for="major">Chọn ngành học (*):</label>
        <select id="major" name="major" required>
            <option value="Ky thuat phan mem">Kỹ thuật phần mềm</option>
            <option value="Khoa hoc may tinh">Khoa học máy tính</option>
            <option value="He thong thong tin">Hệ thống thông tin</option>
        </select><br><br>

        <input type="submit" value="Đăng ký">
    </form>

    <div id="resultMessage" style="margin-top: 20px; padding: 10px; border: 1px solid green; display: none; background-color: #e6ffe6;">
        </div>

    <script>
        function handleRegistration() {
            // Lấy giá trị Tên đăng nhập và Ngành học
            var username = document.getElementById("username").value;
            var major = document.getElementById("major").value;

            // Xử lý thông báo
            var messageDiv = document.getElementById("resultMessage");
            messageDiv.innerHTML = "🎉 Chúc mừng <b>" + username + "</b>!, Bạn đã đăng ký ngành: <b>" + major + "</b>";
            messageDiv.style.display = 'block';

            return false; // Ngăn chặn form submit thực sự (tải lại trang)
        }
    </script>
</body>
</html>