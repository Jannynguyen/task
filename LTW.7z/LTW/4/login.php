<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <title>ĐĂNG NHẬP</title>
</head>
<body>
    <h1>ĐĂNG NHẬP</h1>
    <form action="result.jsp" method="POST">
        <label for="username">Tên đăng nhập:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Mật khẩu:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Đăng nhập">
    </form>
</body>
</html>