<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông Tin Cá Nhân</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
   <h1>Nguyễn Văn A</h1>
    <h2>Nghề nghiệp: Lập trình viên</h2>
    <p style="width: 60%; margin: 20px auto; line-height: 1.5;">
        Tôi là một lập trình viên đam mê sáng tạo và học hỏi. Với hơn 3 năm kinh nghiệm...
    </p>

    <h2>Sở thích</h2>
    <div class="sothich">
        <span onmouseover="doiMau(this)" onmouseout="khoiPhucMau(this)">Học tập và nghiên cứu</span>
        <span onmouseover="doiMau(this)" onmouseout="khoiPhucMau(this)">Chơi thể thao</span>
        <span onmouseover="doiMau(this)" onmouseout="khoiPhucMau(this)">Nghe nhạc, xem phim</span>
        <span onmouseover="doiMau(this)" onmouseout="khoiPhucMau(this)">Du lịch và khám phá</span>
    </div>

    <script>
        function doiMau(element) {
            element.style.backgroundColor = '#007bff'; 
            element.style.color = 'white'; 
        }

        function khoiPhucMau(element) {
            element.style.backgroundColor = 'transparent'; 
            element.style.color = 'black'; 
        }
    </script>

</body>
</html>
