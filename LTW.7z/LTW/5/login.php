<!DOCTYPE html>
<html>
<head>
    <title>ĐĂNG NHẬP</title>
</head>
<body>
    <h1>ĐĂNG NHẬP</h1>
    <form action="welcome.jsp" method="POST">
        <label for="username">Tên đăng nhập:</label><br>
        <input type="text" id="username" name="username" required><br><br>
        <input type="submit" value="Đăng nhập">
    </form>
</body>
</html>