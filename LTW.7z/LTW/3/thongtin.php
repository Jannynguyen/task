<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông Tin Cá Nhân 2</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
 <div class="container">
        <div class="left-panel">
            <img id="avatar" src="images/lazycat.jpg" alt="Ảnh đại diện"
                 onclick="phongToAnh(this)">
        </div>
        <div class="right-panel">
            <h2>THÔNG TIN CÁ NHÂN</h2>
            <div class="info">
                <p><span class="label">Họ và tên:</span> Nguyễn Văn A</p>
                <p><span class="label">Ngày sinh:</span> 15/03/1995</p>
                <p><span class="label">Giới tính:</span> Nam</p>
                </div>
        </div>
    </div>
    <p style="width: 700px; margin: 20px auto;">
        Xin chào! Tôi là một lập trình viên với 3 năm kinh nghiệm...
    </p>

    <script>
        let isZoomed = false;
        function phongToAnh(img) {
            if (isZoomed) {
                img.style.transform = 'scale(1)'; // Thu nhỏ
                img.style.cursor = 'zoom-in';
            } else {
                img.style.transform = 'scale(1.5)'; // Phóng to 1.5 lần
                img.style.cursor = 'zoom-out';
            }
            isZoomed = !isZoomed;
        }
    </script>
</body>
</html>
