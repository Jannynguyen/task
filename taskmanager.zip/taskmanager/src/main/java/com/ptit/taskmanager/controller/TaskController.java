package com.ptit.taskmanager.controller;

import com.ptit.taskmanager.entity.Task;
import com.ptit.taskmanager.entity.User;
import com.ptit.taskmanager.service.TaskService;
import com.ptit.taskmanager.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private UserService userService; // Để lấy đối tượng User từ UserDetails

    // Lấy đối tượng User hiện tại từ Principal
    private User getCurrentUser(UserDetails userDetails) {
        return userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @GetMapping
    public String listTasks(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        User currentUser = getCurrentUser(userDetails);
        List<Task> allTasks = taskService.findTasksByUser(currentUser);

        // Phân loại task theo status để hiển thị trên view
        model.addAttribute("todoTasks", allTasks.stream().filter(t -> "TODO".equalsIgnoreCase(t.getStatus())).collect(Collectors.toList()));
        model.addAttribute("inProgressTasks", allTasks.stream().filter(t -> "IN_PROGRESS".equalsIgnoreCase(t.getStatus())).collect(Collectors.toList()));
        model.addAttribute("doneTasks", allTasks.stream().filter(t -> "DONE".equalsIgnoreCase(t.getStatus())).collect(Collectors.toList()));

        model.addAttribute("username", currentUser.getUsername()); // Hiển thị username trên header
        return "task-list"; // templates/task-list.html
    }

    @GetMapping("/new")
    public String showCreateTaskForm(Model model) {
        model.addAttribute("task", new Task());
        model.addAttribute("pageTitle", "Tạo Task Mới");
        return "task-form"; // templates/task-form.html
    }

    @PostMapping
    public String createTask(@Valid @ModelAttribute("task") Task task,
                             BindingResult bindingResult,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("pageTitle", "Tạo Task Mới");
            return "task-form";
        }
        User currentUser = getCurrentUser(userDetails);
        taskService.saveTask(task, currentUser);
        redirectAttributes.addFlashAttribute("successMessage", "Task đã được tạo thành công!");
        return "redirect:/tasks";
    }

    @GetMapping("/edit/{id}")
    public String showEditTaskForm(@PathVariable Long id, Model model, @AuthenticationPrincipal UserDetails userDetails) {
        User currentUser = getCurrentUser(userDetails);
        Task task = taskService.findTaskByIdAndUser(id, currentUser)
                .orElseThrow(() -> new RuntimeException("Task not found or you don't have permission"));
        model.addAttribute("task", task);
        model.addAttribute("pageTitle", "Chỉnh sửa Task");
        return "task-form";
    }

    @PostMapping("/update/{id}") // Dùng PostMapping cho update
    public String updateTask(@PathVariable Long id, @Valid @ModelAttribute("task") Task taskDetails,
                             BindingResult bindingResult,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("pageTitle", "Chỉnh sửa Task");
            taskDetails.setId(id); // Giữ lại Id khi có lỗi validation
            return "task-form";
        }
        User currentUser = getCurrentUser(userDetails);
        // Lấy task gốc để đảm bảo user không sửa task của người khác
        Task existingTask = taskService.findTaskByIdAndUser(id, currentUser)
                .orElseThrow(() -> new RuntimeException("Task not found or you don't have permission"));

        // Cập nhật thông tin từ form
        existingTask.setTitle(taskDetails.getTitle());
        existingTask.setDescription(taskDetails.getDescription());
        existingTask.setStatus(taskDetails.getStatus());

        taskService.saveTask(existingTask, currentUser); // Lưu lại task đã cập nhật
        redirectAttributes.addFlashAttribute("successMessage", "Task đã được cập nhật thành công!");
        return "redirect:/tasks";
    }

    @GetMapping("/delete/{id}")
    public String deleteTask(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, RedirectAttributes redirectAttributes) {
        User currentUser = getCurrentUser(userDetails);
        try {
            taskService.deleteTask(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Task đã được xóa thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Lỗi xóa task: " + e.getMessage());
        }
        return "redirect:/tasks";
    }
}