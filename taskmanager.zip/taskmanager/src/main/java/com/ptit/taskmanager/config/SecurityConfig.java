package com.ptit.taskmanager.config;

import com.ptit.taskmanager.service.impl.UserDetailsServiceImpl; // Import đúng
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsServiceImpl userDetailsService() {
        return new UserDetailsServiceImpl();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers("/register", "/login", "/css/**", "/js/**").permitAll() // Cho phép truy cập trang đăng ký, đăng nhập và file tĩnh
                        .requestMatchers("/admin/**").hasRole("ADMIN") // Chỉ ROLE_ADMIN được vào /admin/** (ví dụ)
                        .anyRequest().authenticated() // Tất cả các request khác yêu cầu đăng nhập
                )
                .formLogin(form -> form
                        .loginPage("/login") // Trang đăng nhập tùy chỉnh
                        .loginProcessingUrl("/login") // URL xử lý form đăng nhập (mặc định của Spring Security)
                        .defaultSuccessUrl("/tasks", true) // Chuyển đến /tasks sau khi login thành công
                        .failureUrl("/login?error=true") // Chuyển về trang login nếu lỗi
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout=true") // Chuyển về trang login sau khi logout
                        .permitAll()
                )
                .authenticationProvider(authenticationProvider()); // Sử dụng provider đã cấu hình

        return http.build();
    }
}