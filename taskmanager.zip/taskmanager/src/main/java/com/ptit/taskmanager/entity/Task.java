package com.ptit.taskmanager.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "tasks")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Tiêu đề không được để trống")
    @Column(nullable = false, columnDefinition = "NVARCHAR(255)")
    private String title;

    @Column(columnDefinition = "NVARCHAR(MAX)") // Cho phép mô tả dài
    private String description;

    @Column(nullable = false, columnDefinition = "NVARCHAR(50)")
    private String status; // e.g., "TODO", "IN_PROGRESS", "DONE"

    // Mối quan hệ ManyToOne với User
    @ManyToOne(fetch = FetchType.LAZY) // LAZY để không tải user khi chỉ cần task
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}