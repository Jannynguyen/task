package com.ptit.taskmanager.service;

import com.ptit.taskmanager.entity.Task;
import com.ptit.taskmanager.entity.User;
import java.util.List;
import java.util.Optional;

public interface TaskService {
    List<Task> findTasksByUser(User user);
    Optional<Task> findTaskByIdAndUser(Long id, User user);
    void saveTask(Task task, User user);
    void deleteTask(Long id, User user);
}