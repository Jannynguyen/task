package com.ptit.taskmanager.service.impl;

import com.ptit.taskmanager.entity.Task;
import com.ptit.taskmanager.entity.User;
import com.ptit.taskmanager.repository.TaskRepository;
import com.ptit.taskmanager.service.TaskService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Override
    public List<Task> findTasksByUser(User user) {
        return taskRepository.findByUserOrderByStatusAscIdDesc(user);
    }

    @Override
    public Optional<Task> findTaskByIdAndUser(Long id, User user) {
        Optional<Task> taskOpt = taskRepository.findById(id);
        // Kiểm tra xem task có tồn tại và có thuộc về user hiện tại không
        if (taskOpt.isPresent() && taskOpt.get().getUser().getId().equals(user.getId())) {
            return taskOpt;
        }
        return Optional.empty(); // Hoặc ném exception
    }

    @Override
    @Transactional
    public void saveTask(Task task, User user) {
        // Nếu là task mới hoặc task thuộc về user hiện tại thì mới cho lưu
        if (task.getId() == null || (task.getUser() != null && task.getUser().getId().equals(user.getId()))) {
            task.setUser(user); // Đảm bảo task luôn được gán cho user hiện tại
            taskRepository.save(task);
        } else {
            // Ném lỗi nếu cố gắng sửa task của người khác (nếu cần bảo mật chặt hơn)
            throw new AccessDeniedException("Bạn không có quyền sửa task này.");
        }
    }

    @Override
    @Transactional
    public void deleteTask(Long id, User user) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Không tìm thấy Task với id: " + id));

        // Chỉ cho phép xóa nếu task thuộc về user hiện tại
        if (!task.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("Bạn không có quyền xóa task này.");
        }
        taskRepository.deleteById(id);
    }
}