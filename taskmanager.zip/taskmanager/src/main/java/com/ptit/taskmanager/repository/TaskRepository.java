package com.ptit.taskmanager.repository;

import com.ptit.taskmanager.entity.Task;
import com.ptit.taskmanager.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    // Tìm tất cả task của một user cụ thể
    List<Task> findByUserOrderByStatusAscIdDesc(User user); // Sắp xếp theo status rồi id giảm dần
}