package com.ptit.taskmanager.service;

public class UserDetailsService {
}
