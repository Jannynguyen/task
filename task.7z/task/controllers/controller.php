<?php
// Đảm bảo session được khởi động ngay từ đầu
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Nhúng kết nối và các Model (Lưu ý: kiểm tra đúng tên file hoa/thường)
include_once 'config/db.php';
include_once 'models/task.php';
include_once 'models/project.php';
include_once 'models/user.php';

class TaskController {
    private $db;
    private $task;
    private $project;
    private $user;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();

        $this->task = new Task($this->db);
        $this->project = new Project($this->db);
        $this->user = new User($this->db);
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user = $this->user->login($_POST['username']);
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: index.php?action=index");
                exit();
            } else {
                $error = "Tài khoản không tồn tại!";
                include 'views/login.php';
            }
        } else {
            include 'views/login.php';
        }
    }

    public function logout() {
        session_unset();
        session_destroy();
        header("Location: index.php?action=login");
        exit();
    }

public function index() {
    // 1. Kiểm tra quyền đăng nhập (Session)
    if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
        header("Location: index.php?action=login");
        exit();
    }

    try {
        // 2. Lấy dữ liệu từ các Models
        $tasks    = $this->task->readAll()->fetchAll(PDO::FETCH_ASSOC);
        $projects = $this->project->read()->fetchAll(PDO::FETCH_ASSOC);
        $users    = $this->user->readWithUnit()->fetchAll(PDO::FETCH_ASSOC);

        // 3. Xử lý thông báo (Safe check với $_GET)
        $message = "";
        if (isset($_GET['msg'])) {
            $msgType = $_GET['msg'];
            
            switch ($msgType) {
                case 'created':
                    $message = "Thêm công việc thành công!";
                    break;
                case 'deleted':
                    $message = "Đã xóa công việc!";
                    break;
                case 'user_added':
                    $message = "Đã thêm nhân viên mới thành công!";
                    break;
                case 'updated':
                    $message = "Đã cập nhật trạng thái công việc!";
                    break;
                /* 
                  LỖI ĐÃ XẢY RA Ở ĐÂY:
                  case 'updateStatus': $controller->updateStatus(); break;
                  Hành động updateStatus KHÔNG PHẢI là một thông báo (msg), nó là một action chính.
                  Nó phải nằm trong file Router (index.php bên ngoài), không phải ở đây.
                */    
                case 'error':
                    $message = "Có lỗi xảy ra, vui lòng thử lại!";
                    break;
                default:
                    $message = "";
            }
        }

        // 4. Khởi tạo tiêu đề trang
        $pageTitle = "Bảng điều khiển công việc";

        // 5. Gọi View (Truyền các biến $tasks, $projects, $users, $message vào view)
        if (file_exists('views/task_list.php')) {
            include 'views/task_list.php';
        } else {
            die("Lỗi: Không tìm thấy tệp giao diện views/task_list.php");
        }

    } catch (Exception $e) {
        die("Lỗi hệ thống: " . $e->getMessage());
    }
}



    public function store() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: index.php?action=login");
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Lấy dữ liệu từ Form (Khớp với các thuộc tính 'name' trong HTML)
            $title = $_POST['title'] ?? '';
            $description = $_POST['description'] ?? '';
            $project_id = $_POST['project_id'] ?? null;
            $assigned_to = $_POST['assigned_to'] ?? null;

            // Kiểm tra dữ liệu bắt buộc trước khi lưu
            if (!empty($title) && !empty($project_id) && !empty($assigned_to)) {
                if ($this->task->create($title, $description, $project_id, $assigned_to)) {
                    header("Location: index.php?action=index&msg=created");
                    exit();
                }
            }
            
            header("Location: index.php?action=index&msg=error");
            exit();
        }
    }

    public function delete($id) {
        if (!isset($_SESSION['user_id'])) {
            header("Location: index.php?action=login");
            exit();
        }

        if ($id && $this->task->delete($id)) {
            header("Location: index.php?action=index&msg=deleted");
            exit();
        }
        header("Location: index.php?action=index&msg=error");
        exit();
    }
    public function addUser() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php?action=login");
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'] ?? '';
        $unit_id = $_POST['unit_id'] ?? null;

        if (!empty($username) && !empty($unit_id)) {
            if ($this->user->create($username, $unit_id)) {
                header("Location: index.php?action=index&msg=user_added");
                exit();
            }
        }
        header("Location: index.php?action=index&msg=error");
        exit();
    }
}
public function updateStatus() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php?action=login");
        exit();
    }

    $id = $_GET['id'] ?? null;
    $status = $_GET['status'] ?? null;

    if ($id && $status) {
        if ($this->task->updateStatus($id, $status)) {
            header("Location: index.php?action=index&msg=updated");
            exit();
        }
    }
    header("Location: index.php?action=index&msg=error");
    exit();
}


}
