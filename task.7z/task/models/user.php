<?php
class User {
    private $conn;
    public function __construct($db) { $this->conn = $db; }

    public function readWithUnit() {
        $query = "SELECT u.*, b.name as unit_name 
                  FROM users u 
                  JOIN business_units b ON u.unit_id = b.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
    public function login($username) {
        // Trong thực tế cần dùng password_verify, đây là bản đơn giản
        $query = "SELECT * FROM users WHERE username = :username LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function create($username, $unit_id) {
    $query = "INSERT INTO users (username, unit_id) VALUES (:username, :unit_id)";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':unit_id', $unit_id);
    return $stmt->execute();
}

// Thêm hàm lấy danh sách phòng ban để chọn khi tạo user
public function getBusinessUnits() {
    $query = "SELECT * FROM business_units";
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt;
}

}
