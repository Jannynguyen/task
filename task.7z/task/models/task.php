<?php
class Task {
    private $conn;
    private $table = "tasks";

    public function __construct($db) { $this->conn = $db; }

    // Lấy toàn bộ danh sách task (Join nhiều bảng)
    public function readAll() {
        $query = "SELECT t.*, u.username, p.project_name, b.name as unit_name 
                  FROM " . $this->table . " t
                  LEFT JOIN users u ON t.assigned_to = u.id
                  LEFT JOIN projects p ON t.project_id = p.id
                  LEFT JOIN business_units b ON u.unit_id = b.id
                  ORDER BY t.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Thêm mới Task và tự động ghi log vào task_his
    public function create($title, $description, $project_id, $assigned_to) {
        $query = "INSERT INTO " . $this->table . " 
                  SET title=:title, description=:desc, project_id=:p_id, assigned_to=:user";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":title", $title);
        $stmt->bindParam(":desc", $description);
        $stmt->bindParam(":p_id", $project_id);
        $stmt->bindParam(":user", $assigned_to);

        if($stmt->execute()) {
            // Ghi lịch sử (task_his)
            $last_id = $this->conn->lastInsertId();
            $this->logHistory($last_id, "Đã tạo mới task này");
            return true;
        }
        return false;
    }
    public function updateStatus($id, $new_status) {
    $query = "UPDATE tasks SET status = :status WHERE id = :id";
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(':status', $new_status);
    $stmt->bindParam(':id', $id);

    if($stmt->execute()) {
        // Ghi vào lịch sử thay đổi
        $log_query = "INSERT INTO task_his (task_id, change_details) VALUES (?, ?)";
        $log_stmt = $this->conn->prepare($log_query);
        $log_stmt->execute([$id, "Cập nhật trạng thái thành: " . $new_status]);
        return true;
    }
    return false;
}

    // Hàm ghi lịch sử thay đổi
    private function logHistory($task_id, $details) {
        $query = "INSERT INTO task_his (task_id, change_details) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$task_id, $details]);
    }
}
