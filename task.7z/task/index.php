<?php
// Khởi tạo Controller
include_once 'controllers/controller.php';
$controller = new TaskController();

// Kiểm tra hành động người dùng yêu cầu (mặc định là index)
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$id = isset($_GET['id']) ? $_GET['id'] : null;
// Kiểm tra quyền truy cập (ngoại trừ trang login)
if (!isset($_SESSION['user_id']) && $action !== 'login') {
    header("Location: index.php?action=login");
    exit();
}
switch ($action) {
    case 'index':
        $controller->index(); 
        break;    
    case 'store':
        $controller->store(); 
        break;   
    case 'delete':
        $controller->delete($id); // Gọi hàm với tham số ID an toàn
        break;
    case 'login': 
        $controller->login(); 
        break;
    case 'logout': 
        $controller->logout(); 
        break;
    case 'addUser': 
        $controller->addUser(); 
        break; 
    case 'updateStatus': 
        $controller->updateStatus(); 
        break;
    default: 
        $controller->index(); 
        break;
}
