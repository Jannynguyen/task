<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hệ thống Quản lý Tác Vụ Nội bộ</title>
    <!-- Link CSS bên ngoài -->
    <link rel="stylesheet" href="assets/css/styles.css">
    <!-- Font Awesome 6.x cho năm 2025 (Đã sửa link) -->
    <link rel="stylesheet" href="cdnjs.cloudflare.com">
    <!-- Bootstrap 5 cho Grid và Form (Đã sửa link) -->
    <link href="cdn.jsdelivr.net" rel="stylesheet">
</head>
<body>

<div class="container my-4">
    <header class="text-center mb-4">
        <h1><i class="fa-solid fa-list-check"></i> Quản lý Tác Vụ Phòng Ban</h1>
        <p class="subtitle text-secondary">Hệ thống điều phối công việc 2025</p>
        <div class="d-flex justify-content-end">
            <span class="badge bg-info text-dark">
                Xin chào, <?= htmlspecialchars($_SESSION['username']) ?> | 
                <a href="index.php?action=logout" class="text-decoration-none">Đăng xuất</a>
            </span>
        </div>
    </header>

    <!-- Hiển thị thông báo nếu có -->
    <?php if (isset($message) && $message != ""): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="action-bar d-flex justify-content-between align-items-center mb-3">
        <div>
            <!-- Nút bấm để mở Form Thêm mới Task -->
            <button class="btn btn-primary" onclick="toggleCreateForm()">
                <i class="fa-solid fa-plus"></i> Thêm Task Mới
            </button>
            <!-- Nút bấm để mở Form Thêm Nhân sự -->
            <button class="btn btn-info text-white" onclick="toggleUserForm()">
                <i class="fa-solid fa-user-plus"></i> Thêm Nhân Sự
            </button>
        </div>
        <div class="search-box">
            <input type="text" class="form-control" placeholder="Tìm kiếm công việc...">
        </div>
    </div>

    <!-- KHU VỰC INCLUDE FORM TẠO TASK -->
    <div id="create-task-section" style="display: none;">
        <?php include 'views/create_task.php'; ?>
    </div>

    <!-- KHU VỰC INCLUDE FORM TẠO USER -->
    <div id="add-user-section" style="display: none;">
        <?php include 'views/add_user.php'; ?>
    </div>

    <div class="table-wrapper bg-white p-3 rounded shadow-sm">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Công việc</th>
                    <th>Dự án</th>
                    <th>Nhân sự</th>
                    <th>Phòng ban</th>
                    <th style="width: 180px;">Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($tasks)): ?>
                    <?php foreach($tasks as $task): ?>
                    <tr>
                        <td>#<?= $task['id'] ?></td>
                        <td class="task-title fw-bold"><?= htmlspecialchars($task['title']) ?></td>
                        <td><span class="badge bg-light text-primary border"><?= htmlspecialchars($task['project_name']) ?></span></td>
                        <td><strong><?= htmlspecialchars($task['username']) ?></strong></td>
                        <td><?= htmlspecialchars($task['unit_name']) ?></td>
                        
                        <!-- CỘT TRẠNG THÁI VÀ NÚT SỬA -->
                        <td>
                            <div class="status-group">
                                <?php 
                                    $statusClass = 'bg-secondary';
                                    if($task['status'] == 'Todo') $statusClass = 'bg-warning text-dark';
                                    if($task['status'] == 'In Progress') $statusClass = 'bg-primary';
                                    if($task['status'] == 'Done') $statusClass = 'bg-success';
                                ?>
                                <span class="badge <?= $statusClass ?> status-badge mb-1">
                                    <?= $task['status'] ?>
                                </span>

                                <div class="status-actions">
                                    <?php if($task['status'] != 'Todo'): ?>
                                        <a href="index.php?action=updateStatus&id=<?= $task['id'] ?>&status=Todo" title="Về Todo"><i class="fa-solid fa-rotate-left text-secondary"></i></a>
                                    <?php endif; ?>
                                    <?php if($task['status'] != 'In Progress'): ?>
                                        <a href="index.php?action=updateStatus&id=<?= $task['id'] ?>&status=In Progress" title="Đang làm"><i class="fa-solid fa-person-digging text-primary"></i></a>
                                    <?php endif; ?>
                                    <?php if($task['status'] != 'Done'): ?>
                                        <a href="index.php?action=updateStatus&id=<?= $task['id'] ?>&status=Done" title="Hoàn thành"><i class="fa-solid fa-check-circle text-success"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>

                        <td class="actions">
                            <a href="index.php?action=delete&id=<?= $task['id'] ?>" class="text-danger text-decoration-none" onclick="return confirm('Xóa task này?')">
                                <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center text-muted p-4">Chưa có công việc nào được phân công.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Script để ẩn hiện Form TASK -->
<script>
function toggleCreateForm() {
    var x = document.getElementById("create-task-section");
    x.style.display = (x.style.display === "none") ? "block" : "none";
}
// Script để ẩn hiện Form USER
function toggleUserForm() {
    var x = document.getElementById("add-user-section");
    x.style.display = (x.style.display === "none") ? "block" : "none";
}
</script>

<!-- Bootstrap JS (Đã sửa link) -->
<script src="cdn.jsdelivr.net"></script>
</body>
</html>
