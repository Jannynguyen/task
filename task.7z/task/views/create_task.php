<!-- Form Thêm Task Mới -->
<div class="card shadow">
    <div class="card-header bg-primary">
        <h5 class="mb-0"><i class="fa-solid fa-plus-circle"></i> Thêm công việc mới</h5>
    </div>
    <div class="card-body">
        <!-- Đảm bảo action đúng với route trong index.php -->
        <form action="index.php?action=store" method="POST" class="row">
            
            <div class="col-12">
                <label class="form-label">Tiêu đề Task</label>
                <input type="text" name="title" class="form-control" placeholder="Nhập tên công việc..." required>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold">Dự án</label>
                <select name="project_id" class="form-select" required>
                    <option value="">-- Chọn dự án --</option>
                    <?php if (!empty($projects)): ?>
                        <?php foreach($projects as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['project_name']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold">Giao cho nhân sự</label>
                <select name="assigned_to" class="form-select" required>
                    <option value="">-- Chọn người thực hiện --</option>
                    <?php if (!empty($users)): ?>
                        <?php foreach($users as $u): ?>
                            <option value="<?= $u['id'] ?>">
                                <?= htmlspecialchars($u['username']) ?> (<?= htmlspecialchars($u['unit_name'] ?? 'N/A') ?>)
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-12">
                <label class="form-label">Mô tả chi tiết</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Nhập nội dung công việc..."></textarea>
            </div>

            <div class="col-12">
                <a href="index.php" class="btn btn-light border">Hủy</a>
                <button type="submit" name="btnSave" class="btn btn-success">
                    <i class="fa-solid fa-floppy-disk"></i> Lưu Task
                </button>
            </div>
        </form>
    </div>
</div>
<!-- Nút bấm để mở Form Thêm User -->
<button class="btn btn-info text-white" onclick="toggleUserForm()">
    <i class="fa-solid fa-user-plus"></i> Thêm Nhân Sự
</button>

<div id="add-user-section" style="display: none;">
    <?php include 'views/add_user.php'; ?>
</div>

<script>
function toggleUserForm() {
    var x = document.getElementById("add-user-section");
    x.style.display = (x.style.display === "none") ? "block" : "none";
}
</script>
