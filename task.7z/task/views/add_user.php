<div class="card shadow">
    <div class="card-header bg-primary">
        <h5 class="mb-0"><i class="fa-solid fa-user-plus"></i> Thêm Nhân Sự Mới</h5>
    </div>
    <div class="card-body">
        <form action="index.php?action=addUser" method="POST" class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Tên đăng nhập (Username)</label>
                <input type="text" name="username" class="form-control" placeholder="Ví dụ: nguyenvanc" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Phòng ban</label>
                <select name="unit_id" class="form-select" required>
                    <option value="">-- Chọn phòng ban --</option>
                    <?php 
                        // Lấy danh sách phòng ban từ db
                        $units = $this->user->getBusinessUnits()->fetchAll(PDO::FETCH_ASSOC);
                        foreach($units as $unit): 
                    ?>
                        <option value="<?= $unit['id'] ?>"><?= htmlspecialchars($unit['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-info text-white px-4">Lưu Nhân Viên</button>
            </div>
        </form>
    </div>
</div>
