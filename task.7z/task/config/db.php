<?php
class Database {
    private $host = "localhost";
    private $db_name = "tasksdb"; // Kiểm tra lại tên DB của bạn
    private $username = "root";
    private $password = "";
    public $conn;

    // Đảm bảo tên hàm KHÔNG có khoảng trắng và đúng chữ hoa chữ thường
    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                $this->username, 
                $this->password
            );
            // Thiết lập font chữ tiếng Việt và chế độ báo lỗi
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Lỗi kết nối: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>
